import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom"; 
import styled from "styled-components";
import DynamicsCardInput from "./DynamicsCards/DynamicsCardInput";
import NewStudentPage from "./Pages/NewStudentPage";

type RoutesProps = {
    className?: string;
}

const RoutesApp = ({ className }: RoutesProps) => {
    return (
        <div className={className}>
            <BrowserRouter>
                <Routes>
                    <Route path="/card" element={<DynamicsCardInput />} />
                    <Route path="/page" element={<NewStudentPage />} />
                </Routes>
            </BrowserRouter>
        </div>
    )
}

export default styled(RoutesApp)``
;