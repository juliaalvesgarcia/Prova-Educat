import React, { useState } from "react";
import styled from "styled-components";
import DynamicsCardInput from "../DynamicsCards/DynamicsCardInput";
import ManageSearchIcon from '@mui/icons-material/ManageSearch';

type NewStudentPageProps = {
    className?: string;
    isDisbled?: boolean;
}

const jsonAlunos = {
    alunos: [
        {
            name: "Julia Alves Garcia",
            email:"julalvesgarcia@gmail.com",
            number:"31920027685",
            vigencia:"13/03/2021 à 13/03/2023"
        },
        {
            name: "Isabela Alves",
            email:"julalvesgarcia@gmail.com",
            number:"31920027685",
            vigencia:"13/03/2021 à 13/03/2023"
        },
        {
            name: "Filipe",
            email:"julalvesgarcia@gmail.com",
            number:"31920027685",
            vigencia:"13/03/2021 à 13/03/2023"
        },
    ],
};

const NewStudentPage = ({className}: NewStudentPageProps) => {
    const [searchName, setSearchName] = useState("");
    return(
        <div className={className}>
            <div className="top">
                <div className="filter">
                    <input
                    placeholder="Buscar"
                    className="inputBusca"
                    onChange={(event) => {
                        setSearchName(event.target.value);}}>
                    </input>
                </div>
                <div>
                    <button className="btn">
                        <div><ManageSearchIcon /></div>
                        <div><label>Filtros</label></div>
                    </button>
                </div>                
            </div>
            <div className="students">
                {jsonAlunos.alunos
                .filter((aluno: any) => {
                    if (searchName === ""){
                        return aluno;
                    } else if (aluno.name.toLowerCase().includes(searchName.toLowerCase())){
                        return aluno;
                    }
                }).map((aluno:any) => {
                    return(
                        <div className="dinamico">
                            <DynamicsCardInput 
                            name={aluno.name}
                            email={aluno.email}
                            number={aluno.number}
                            vigencia={aluno.vigencia}
                            />
                        </div>
                    );
                })}
            </div>
        </div>
    )
}

export default styled(NewStudentPage)`
    height: 100%;
    width: 100%;

    .dinamico{
        
    }
    .btn{
        display: flex;
        flex-direction: row;
        align-items: center;
    }
    .top{
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: space-between;

    }
    .inputBusca{
        border-top: 0px;
        border-left: 0px;
        border-right: 0px;
        border-bottom: 0.976562px solid #7D7D7D;    
        width: 100%;
        display: flex;
    }
`;