import React from "react";
import styled from "styled-components";
import Aside from "./Layout/Aside";
import Content from "./Layout/Content";
import MainHeader from "./Layout/MainHeader";

type LayoutProps = {
    className?: string;
    children?: string;
}

const Layout = ({ className, children }: LayoutProps) => {
    return (
        <div className={className}>
            <MainHeader />
            <Aside />
            <Content>{children}</Content>
        </div>
    );
};

export default styled(Layout)`
    height: 100vh;
    width: 100%;
    display: grid;
    grid-template-columns: 240px auto;
    grid-template-rows: 64px auto;
    grid-template-areas: 
        "MH MH"
        "AS CT";

`;