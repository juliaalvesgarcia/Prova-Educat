import React from "react";
import styled from "styled-components";

type MainHeaderProps = {
    className?: string;
    children?: any;
}

const MainHeader = ({className, children}: MainHeaderProps) => {
    return (
        <div className={className}>
            {children}
        </div>
    )
}

export default styled(MainHeader)`
    height: 100%;
    width: 100%;
    grid-area: MH;
    background-color: green;
`;