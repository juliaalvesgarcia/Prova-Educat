import React from "react";
import styled from "styled-components";
import DateRangeIcon from '@mui/icons-material/DateRange';
import ArticleIcon from '@mui/icons-material/Article';
import AttachMoneyIcon from '@mui/icons-material/AttachMoney';
import CreateIcon from '@mui/icons-material/Create';
import AccountCircleIcon from '@mui/icons-material/AccountCircle';
import EmailIcon from '@mui/icons-material/Email';
import PhoneIphoneIcon from '@mui/icons-material/PhoneIphone';

type DynamicsCardStudentProps = {
    className?: string;
    name?: string;
    email?: string;
    number?: string;
    vigencia?: string;
}

const DynamicsCardsStudent = ({className, name, email, number,vigencia}: DynamicsCardStudentProps) =>{
    return(
        <div className={className}>
            <div className="perfil">
                <div>
                    <div className="info_name">
                        <div><label>{name}</label></div>
                        <div className="btn">
                            <DateRangeIcon sx={{ color: "#5F5F5F"}}/>
                            <ArticleIcon sx={{ color: "#5F5F5F"}}/>
                            <AttachMoneyIcon sx={{ color: "#5F5F5F"}}/>
                            <CreateIcon sx={{ color: "#5F5F5F"}}/>
                        </div>
                    </div>
                    <div className="information">
                        <div>
                            <label><EmailIcon />{email}</label>
                        </div>
                        <div>
                            <label><PhoneIphoneIcon />{number}</label>
                        </div>
                        <div>
                            <label>{vigencia}</label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default styled(DynamicsCardsStudent)`
    width: 100%;
    height: 100%;

    .info_name{
        display: flex;
        flex-direction: row;
        justify-content: space-between;
    }
    .information{
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: flex-start;
    }

`;
